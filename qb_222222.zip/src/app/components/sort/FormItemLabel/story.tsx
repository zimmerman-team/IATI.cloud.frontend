import React from 'react';
import { storiesOf } from '@storybook/react';
import Component from './index';
import Providers from 'app/Providers';
import RadioButton from 'app/components/inputs/radiobuttons/RadioButton';
import { Switch, Checkbox } from '@material-ui/core';

storiesOf('Sort|Components', module).add('Form item label', () => (
  <Providers>
    <Component control={<RadioButton />} label="Each unique activity" />
    <Component control={<Switch />} label="Each unique activity" />
    <Component control={<Checkbox />} label="Each unique activity" />
  </Providers>
));
