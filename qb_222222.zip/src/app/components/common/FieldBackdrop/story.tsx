import React from 'react';
import { storiesOf } from '@storybook/react';
import Component from '.';
import Providers from 'app/Providers';

storiesOf('Backdrop', module).add('Drop', () => (
  <Providers>
    <Component />
  </Providers>
));
