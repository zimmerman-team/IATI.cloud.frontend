import React from 'react';
import { storiesOf } from '@storybook/react';
import Component from '.';
import Providers from 'app/Providers';

storiesOf('Common|Sort', module).add('Field Input Label', () => (
  <Providers>
    <Component label="field input label" />
  </Providers>
));
