import React from 'react';
import { storiesOf } from '@storybook/react';
import { ZZLogo } from '.';
import Providers from 'app/Providers';

storiesOf('SVG,s', module).add('IATI Logos', () => (
  <Providers>
    <ZZLogo />
  </Providers>
));

