import React from 'react';
import { storiesOf } from '@storybook/react';
import Providers from 'app/Providers';
import { Grid } from '@material-ui/core';
import { AddFilterModule } from './index';

storiesOf('Surfaces|Modules/', module).add('Pop over', () => (
  <Providers>
    <Grid container>
      <Grid item>
        <AddFilterModule />
      </Grid>
    </Grid>
  </Providers>
));
