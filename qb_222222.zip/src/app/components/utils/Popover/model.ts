export type PopoverModel = {
  content: any;
};
