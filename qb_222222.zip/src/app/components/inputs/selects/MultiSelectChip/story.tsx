import React from 'react';
import { storiesOf } from '@storybook/react';
import Component from '.';
import Providers from 'app/Providers';
import { Grid } from '@material-ui/core';
import { suggestions } from './mock';

storiesOf('Inputs|Selects/', module).add('Multi Select Chips ', () => (
  <Providers>
    <div>
      <Grid container spacing={4}>
        <Grid item xs={6}>
          <Component label="Multi select with label" options={suggestions} />
        </Grid>
        <Grid item xs={6}>
          <Component
            label="Multi select with assistive text"
            helperText="Assitive text"
            options={suggestions}
          />
        </Grid>
      </Grid>
      <Grid container spacing={4} direction="column">
        <Grid item xs={3}>
          <Component
            label="Multi select with tooltip"
            tooltip="This is a tooltip"
            options={suggestions}
          />
        </Grid>
        <Grid item xs={3}>
          <Component
            label="Multi select with placeholder"
            placeholder="Select something..."
            options={suggestions}
          />
        </Grid>
      </Grid>
      <Grid container spacing={4} direction="row">
        <Grid item xs={6}>
          <Component
            label="Multi select with search"
            search
            options={suggestions}
          />
        </Grid>
        <Grid item xs={6}>
          <Component
            label="Multi select with all options"
            tooltip="This is a tooltip"
            helperText="Assitive text"
            placeholder="Select something..."
            search
            options={suggestions}
          />
        </Grid>
      </Grid>
    </div>
  </Providers>
));
