import React from 'react';
import { storiesOf } from '@storybook/react';
import IconButton from './index';
import Providers from 'app/Providers';
import Download from '@material-ui/icons/GetApp';
import Add from '@material-ui/icons/Add';
import { Grid } from '@material-ui/core';

storiesOf('Inputs|Buttons/', module).add('IconButton', () => (
  <Providers>
    <Grid container direction="column" spacing={3}>
      <Grid item xs={3}>
        <IconButton label="More" icon={<Add />} />
      </Grid>
      <Grid item xs={3}>
        <IconButton label="XML Workbook" />
      </Grid>
      <Grid item xs={3}>
        <IconButton label="Download CSV" icon={<Download />} disabled />
      </Grid>
      <Grid item xs={3}>
        <IconButton label="Download JSON" icon={<Download />} disabled />
      </Grid>
      <Grid item xs={3}>
        <IconButton label="Download XML" icon={<Download />} disabled />
      </Grid>
      <Grid item xs={3}>
        <IconButton label="Download XLS" icon={<Download />} disabled />
      </Grid>
    </Grid>
  </Providers>
));
