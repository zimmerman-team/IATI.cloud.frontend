import React from 'react';
import { storiesOf } from '@storybook/react';
import BaseButton from './index';
import Providers from 'app/Providers';

storiesOf('Inputs|Buttons', module).add('BaseButton', () => (
  <Providers>
    <BaseButton label="Large" size="large" variant="contained" />
    <BaseButton label="Medium" variant="contained" />
    <BaseButton label="Small" size="small" variant="contained" />
    <BaseButton label="Large" size="large" variant="disabled" />
    <BaseButton label="Medium" variant="disabled" />
    <BaseButton label="Small" size="small" variant="disabled" />
  </Providers>
));
