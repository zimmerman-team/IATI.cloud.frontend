import React from 'react';
import { storiesOf } from '@storybook/react';
import IconButtonOutlined from './index';
import Providers from 'app/Providers';

storiesOf('Inputs|Buttons/', module).add('IconButtonOutlined', () => (
  <Providers>
    <IconButtonOutlined label="XML Workbook" />
  </Providers>
));
