import React from 'react';
import { storiesOf } from '@storybook/react';
import AppBarButton from './index';
import Providers from 'app/Providers';

storiesOf('Inputs|Buttons/', module).add('AppBarButton', () => (
  <Providers>
    <AppBarButton label="XML Workbook" />
  </Providers>
));
