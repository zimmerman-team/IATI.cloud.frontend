import React from 'react';
import { storiesOf } from '@storybook/react';
import { ArticleCard } from './index';
import Providers from 'app/Providers';
import { Grid } from '@material-ui/core';
import { ArticleCardMock } from './mock';

storiesOf('Surfaces|Cards/', module).add('Article Card', () => (
  <Providers>
    <Grid container>
      <Grid item xs={4}>
        <ArticleCard
          title={ArticleCardMock.title}
          description={ArticleCardMock.description}
          buttonLabel={ArticleCardMock.buttonLabel}
        />
      </Grid>
    </Grid>
  </Providers>
));
