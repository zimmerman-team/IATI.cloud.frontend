import React from 'react';
import { storiesOf } from '@storybook/react';

import Providers from 'app/Providers';
import IconCheckboxUnchecked from 'app/assets/icons/IconCheckboxUnchecked';
import IconChecked from 'app/assets/icons/IconChecked';
import IconChipDelete from 'app/assets/icons/IconChipDelete';
import IconUnchecked from 'app/assets/icons/IconUnchecked';
import IconTooltip from 'app/assets/icons/IconTooltip';
import IconDropdown from 'app/assets/icons/IconDropdown';

storiesOf('Data display|Icons', module).add('Icons', () => (
  <Providers>
    <IconCheckboxUnchecked />
    <IconChecked />
    <IconChipDelete />
    <IconDropdown />
    <IconTooltip />
    <IconUnchecked />
  </Providers>
));
