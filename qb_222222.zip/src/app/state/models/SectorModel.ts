export type SectorModel = {
  code: string;
  name: string;
};
