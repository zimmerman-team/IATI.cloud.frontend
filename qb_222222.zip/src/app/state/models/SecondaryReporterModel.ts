export type SecondaryReporterModel = {
  code: string;
  name: string;
};
