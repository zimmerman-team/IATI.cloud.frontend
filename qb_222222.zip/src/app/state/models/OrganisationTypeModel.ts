export type OrganisationTypeModel = {
  code: string;
  name: string;
};
