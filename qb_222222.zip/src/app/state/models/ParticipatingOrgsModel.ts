export type ParticipatingOrgsModel = {
  field: string;
  value: string;
  count: number;
};
