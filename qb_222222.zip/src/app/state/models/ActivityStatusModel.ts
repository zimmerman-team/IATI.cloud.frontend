export type ActivityStatusModel = {
  code: string;
  name: string;
};
