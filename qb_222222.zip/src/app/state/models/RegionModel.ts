export type RegionModel = {
  recipient_region: any;
  count: number;
};
