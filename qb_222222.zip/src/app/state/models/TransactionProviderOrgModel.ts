export type TransactionProviderOrgModel = {
  field: string;
  value: string;
  count: string;
};
