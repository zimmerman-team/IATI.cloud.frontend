export type SectorCategoryModel = {
  code: string;
  name: string;
  language: string;
  description?: string;
};
