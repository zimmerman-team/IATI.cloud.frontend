import styled from 'styled-components';
export const Code = styled.code`
  font-size: 12px;
  color: rgba(34, 34, 34, 0.38);

`;
