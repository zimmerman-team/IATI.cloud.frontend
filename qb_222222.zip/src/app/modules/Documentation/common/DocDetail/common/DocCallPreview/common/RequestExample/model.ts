export type RequestExampleModel = {};
