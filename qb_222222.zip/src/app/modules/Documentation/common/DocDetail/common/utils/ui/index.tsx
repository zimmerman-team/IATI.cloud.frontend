import styled from "styled-components";

export const ApiItemDivider = styled.div`
  width: 100%;
  height: 1px;
  background-color: #f0f3f7;
`;
