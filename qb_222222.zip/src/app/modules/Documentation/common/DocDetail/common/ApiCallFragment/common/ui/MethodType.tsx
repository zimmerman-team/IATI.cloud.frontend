import styled from 'styled-components';
export const MethodType = styled.div`
  margin-right: 10px;
  color: green;
`;
