import styled from 'styled-components';
export const CategoryContainer = styled.div`
  margin-bottom: 20px;
`;
