import styled from 'styled-components';
export const SubItemContainer = styled.div`
  padding-left: 10px;
`;
