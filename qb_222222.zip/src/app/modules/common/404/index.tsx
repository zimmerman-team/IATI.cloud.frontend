/* base */
import React from 'react';
import styled from 'styled-components';

const ComponentBase = styled.div``;

const NotFoundModule = () => {
  return <ComponentBase>joe, not found</ComponentBase>;
};

export default NotFoundModule;
