export type FragmentBaseModel = {
  name: string;
  description?: string;
};
