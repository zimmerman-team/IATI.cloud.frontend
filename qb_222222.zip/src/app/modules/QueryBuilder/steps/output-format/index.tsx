import React from 'react';
import { OutputFragment } from 'app/modules/QueryBuilder/steps/output-format/common/OutputFragment';

export function OutputFormatSubModule() {
  return <OutputFragment />;
}
