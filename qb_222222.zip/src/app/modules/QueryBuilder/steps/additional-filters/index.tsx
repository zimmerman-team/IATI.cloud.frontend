import React from 'react';
import { FilterFragment } from 'app/modules/QueryBuilder/steps/additional-filters/common/FilterFragment';

export function AdditionalFiltersSubModule() {
  return <FilterFragment />;
}
