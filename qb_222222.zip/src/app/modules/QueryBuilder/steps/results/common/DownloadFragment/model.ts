import { FragmentBaseModel } from 'app/modules/QueryBuilder/fragments';

export const fragmentConfig: FragmentBaseModel = {
  name: 'Files',
  description: 'Lorem',
};
