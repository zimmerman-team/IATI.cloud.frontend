import React from 'react';
import { DownloadFragment } from 'app/modules/QueryBuilder/steps/results/common/DownloadFragment';

export function ResultsSubModule() {
  return <DownloadFragment />;
}
