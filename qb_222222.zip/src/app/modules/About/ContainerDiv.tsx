import styled from 'styled-components';
export const ContainerDiv = styled.div`
  height: calc(100vh - 290px);
  overflow-y: scroll;
`;
