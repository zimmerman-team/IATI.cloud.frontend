export const fragmentSpace: number = 3;
