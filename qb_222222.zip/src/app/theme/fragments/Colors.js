const Colors = {
  name: 'Landing'
};

export default Colors;
