// typings/modules.d.ts
declare module 'MyTypes';
declare module 'react-test-renderer';
