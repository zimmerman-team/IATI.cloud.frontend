// typings/augmentations.ts

// import { Operator } from 'rxjs/Operator';
// import { Observable } from 'rxjs/Observable';
// declare module 'rxjs/Subject' {
//   // tslint:disable-next-line:interface-name
//   interface Subject<T> {
//     lift<R>(operator: Operator<T, R>): Observable<R>;
//   }
// }
