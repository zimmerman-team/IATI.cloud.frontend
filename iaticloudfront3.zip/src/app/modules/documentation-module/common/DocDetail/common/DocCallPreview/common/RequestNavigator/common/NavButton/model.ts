export type NavButtonModel = {
  label: string;
  path?: string;
  active?: boolean;
};
