import styled from 'styled-components';
export const ParameterHeader = styled.div`
  border-top: 1px solid #f0f3f7;
  border-bottom: 1px solid #f0f3f7;
  margin-bottom: 20px;
  padding-top: 10px;
  padding-bottom: 10px;
`;
