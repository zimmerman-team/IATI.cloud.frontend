import styled from 'styled-components';

export const CallHeader = styled.div`
  display: flex;
  font-size: 18px;
  font-weight: 500;
`;
