import styled from 'styled-components';
export const ItemContainer = styled.div`
  margin-bottom: 10px;
  padding-left: 10px;
`;
