import styled from 'styled-components/macro';

export const CategoryContainer = styled.div`
  margin-bottom: 20px;
`;
