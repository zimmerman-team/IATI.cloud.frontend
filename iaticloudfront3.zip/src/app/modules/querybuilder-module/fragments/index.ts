export interface FragmentBaseModel {
  name: string;
  description?: string;
}
