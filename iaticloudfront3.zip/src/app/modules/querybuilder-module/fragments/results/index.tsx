// cc:query builder module#; query builder fragments - results
import React from 'react';
import { DownloadFragment } from 'app/modules/querybuilder-module/fragments/results/layout';

export function ResultsSubModule() {
  return <DownloadFragment />;
}
