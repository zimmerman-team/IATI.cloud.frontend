import styled from 'styled-components';

export const ParagraphContainer = styled.div`
  padding-bottom: 8px;
`;
