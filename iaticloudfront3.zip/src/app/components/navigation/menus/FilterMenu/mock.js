const data = [
  [
    'Activity',
    [
      'Activity Status',
      'Activity period',
      'Activity Scope',
      'Aid type',
      'Aid Type (category)',
      'Aid Type Vocabulary'
    ]
  ],
  [
    'Transaction',
    [
      'Budget identifier',
      'Budget identifier sector',
      'Budget identifier sector (catagory)',
      'To prove scrollable menu1',
      'To prove scrollable menu2',
      'To prove scrollable menu3',
      'To prove scrollable menu4',
      'To prove scrollable menu5',
      'To prove scrollable menu6',
      'To prove scrollable menu7',
      'To prove scrollable menu8',
      'To prove scrollable menu9',
      'To prove scrollable menu10'
    ]
  ]
];

export default data;
