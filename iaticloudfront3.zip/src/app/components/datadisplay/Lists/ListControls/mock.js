const data = [
  [
    'Activity',
    [
      'Activity Status',
      'Activity period',
      'Activity Scope',
      'Aid type',
      'Aid Type (category)',
      'Aid Type Vocabulary'
    ]
  ],
  [
    'Transaction',
    [
      'Budget identifier',
      'Budget identifier sector',
      'Budget identifier sector (catagory)',
      'Budget identifier',
      'Budget identifier sector',
      'Budget identifier sector (catagory)',
      'Budget identifier',
      'Budget identifier sector',
      'Budget identifier sector (catagory)'
    ]
  ]
];

export default data;
