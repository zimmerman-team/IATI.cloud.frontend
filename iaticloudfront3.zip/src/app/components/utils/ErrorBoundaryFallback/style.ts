export const ComponentBase = `
`;
