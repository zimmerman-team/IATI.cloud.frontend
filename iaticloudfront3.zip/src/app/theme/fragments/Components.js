const Components = {
  name: 'Landing'
};

export default Components;
