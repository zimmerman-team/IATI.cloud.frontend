export interface SectorVocabularyModel {
  code: string;
  name: string;
  language: string;
  description?: string;
}
