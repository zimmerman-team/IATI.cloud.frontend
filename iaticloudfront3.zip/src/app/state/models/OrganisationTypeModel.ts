export interface OrganisationTypeModel {
  code: string;
  name: string;
}
