export interface ParticipatingOrgsModel {
  field: string;
  value: string;
  count: number;
}
