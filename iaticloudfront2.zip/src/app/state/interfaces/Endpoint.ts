export type Endpoint = <T>(params?: RequestInit) => Promise<T>;
