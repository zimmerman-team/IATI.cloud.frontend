export interface SectorModel {
  code: string;
  name: string;
}
