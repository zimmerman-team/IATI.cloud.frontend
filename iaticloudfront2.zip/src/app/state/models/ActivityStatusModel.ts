export interface ActivityStatusModel {
  code: string;
  name: string;
}
