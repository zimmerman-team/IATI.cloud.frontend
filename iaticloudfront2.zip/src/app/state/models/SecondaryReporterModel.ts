export interface SecondaryReporterModel {
  code: string;
  name: string;
}
