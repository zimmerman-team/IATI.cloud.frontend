export interface CountryModel {
  /* todo: add specific type */
  recipient_country: any;
  count: number;
}
