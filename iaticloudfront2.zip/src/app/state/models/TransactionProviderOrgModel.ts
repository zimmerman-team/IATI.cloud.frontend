export interface TransactionProviderOrgModel {
  field: string;
  value: string;
  count: string;
}
