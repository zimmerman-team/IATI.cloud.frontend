export interface RegionModel {
  recipient_region: any;
  count: number;
}
