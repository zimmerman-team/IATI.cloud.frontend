import * as logger from 'app/state/services/logger-service';
import * as localStorage from 'app/state/services/local-storage-service';

export default {
  logger,
  localStorage,
};
