const Layout = {
  name: 'Landing'
};

export default Layout;
