// textStyles

export default {};
