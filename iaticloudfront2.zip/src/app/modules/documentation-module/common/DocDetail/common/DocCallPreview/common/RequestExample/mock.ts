export const ReqyestExampleMock = {};
