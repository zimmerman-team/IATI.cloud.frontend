import styled from 'styled-components';
export const LandingEndpointItem = styled.li`
  font-family: 'Roboto Mono', monospace;
  font-size: 14px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: rgba(34, 34, 34, 0.38);
`;
