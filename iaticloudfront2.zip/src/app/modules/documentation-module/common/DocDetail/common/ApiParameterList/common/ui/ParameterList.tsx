import styled from 'styled-components';
export const ParameterList = styled.div`
  list-style: none;
  margin: 0;
  padding: 0;
`;
