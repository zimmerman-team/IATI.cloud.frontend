//cc:query builder module#; query builder fragments - output format
import React from 'react';
import { OutputFragment } from 'app/modules/querybuilder-module/fragments/output-format/layout';

export function OutputFormatSubModule() {
  return <OutputFragment />;
}
