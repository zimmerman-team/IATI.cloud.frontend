//cc:query builder module#; query builder fragments - additional filters;
import React from 'react';
import { FilterFragment } from 'app/modules/querybuilder-module/fragments/additional-filters/layout';

export function AdditionalFiltersSubModule() {
  return <FilterFragment />;
}
