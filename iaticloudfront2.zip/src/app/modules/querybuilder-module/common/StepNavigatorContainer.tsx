import styled from 'styled-components';

export const StepNavigatorContainer = styled.div`
  /* height: calc(100vh - 185px); */
  overflow-y: auto;
`;
