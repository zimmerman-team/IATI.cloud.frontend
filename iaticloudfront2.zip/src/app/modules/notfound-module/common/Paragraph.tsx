import styled from 'styled-components';

export const Paragraph = styled.p`
  padding-bottom: 8px;
`;
