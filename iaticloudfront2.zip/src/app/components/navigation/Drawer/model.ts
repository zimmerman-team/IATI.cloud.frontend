export type DrawerMenuModel = {
  links: Link[];
};

export type Link = {
  label: string;
  url: string;
};
