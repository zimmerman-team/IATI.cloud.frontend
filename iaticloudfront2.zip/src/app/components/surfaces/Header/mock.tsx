import { HeaderModel } from './model';
import React from 'react';
import { Box } from '@material-ui/core';

export const mockData: HeaderModel = {
  children: <Box width="100%" height="300px" bgcolor="black" />,
};
